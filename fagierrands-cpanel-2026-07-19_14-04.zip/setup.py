import os
import sys
import subprocess

# Security token - change this after use
SECRET = "run-setup-fagierrands-2026"

def application(environ, start_response):
    token = environ.get('QUERY_STRING', '')
    
    if token != f"token={SECRET}":
        start_response('403 Forbidden', [('Content-Type', 'text/plain')])
        return [b'Forbidden']

    sys.path.insert(0, os.path.dirname(__file__))
    from dotenv import load_dotenv
    load_dotenv(os.path.join(os.path.dirname(__file__), '.env'))
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'fagierrands.settings')

    import django
    django.setup()

    output = []

    # Run migrate
    try:
        from django.core.management import call_command
        from io import StringIO
        buf = StringIO()
        call_command('migrate', '--noinput', stdout=buf, stderr=buf)
        output.append("=== MIGRATE ===\n" + buf.getvalue())
    except Exception as e:
        output.append(f"=== MIGRATE ERROR ===\n{e}")

    # Run collectstatic
    try:
        buf2 = StringIO()
        call_command('collectstatic', '--noinput', stdout=buf2, stderr=buf2)
        output.append("=== COLLECTSTATIC ===\n" + buf2.getvalue())
    except Exception as e:
        output.append(f"=== COLLECTSTATIC ERROR ===\n{e}")

    output.append("\n=== DONE — DELETE setup.py FROM SERVER NOW ===")

    body = "\n".join(output).encode()
    start_response('200 OK', [('Content-Type', 'text/plain')])
    return [body]
