import os
import sys

# Add app directory to path
sys.path.insert(0, os.path.dirname(__file__))

# Explicitly load .env file (cPanel doesn't auto-load it)
from dotenv import load_dotenv
load_dotenv(os.path.join(os.path.dirname(__file__), '.env'))

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'fagierrands.settings')

from django.core.wsgi import get_wsgi_application
application = get_wsgi_application()
